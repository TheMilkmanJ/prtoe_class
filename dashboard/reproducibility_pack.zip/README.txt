========================================================================
 COSMICDASHBOARD RUN REPRODUCIBILITY PACK
========================================================================

This pack contains all key files necessary to reproduce the cosmology
inference results for journal publication.

Author: Justin Ryan Pulford
Date: 2026-06-19 22:09:22
Original Config: lcdm_config.yaml
Total chi2: Unknown
========================================================================
